package jssp;

public class VariablesBA {
	
	public static int numberOfOnlookerBees = 30;
	public static int numberOfFoodSources = 15;
	public static int numberOfTrialsToFindBetterFood = 20;
	public static double maxPosition = 2.0;
	public static double minPosition = 0.0;
	
	public static double minRandomNumberEmploedBeePhase = -1;
	public static double maxRandomNumberEmploedBeePhase = 1;

	public static double swapBasedTreeSearchRate = 0.05;

	
	public static int numberOfLevelsTreeSearch = 4;
	public static int numberOfDifferentLocationsCriticalBox = 20;
	public static int numberOfTraialsForEachSolution = 10;
	
	public static double multiTypeIndividualEnhancementSchemeRate = 0.01;

}
